
<h1>Error {{ $error_code  }}</h1>
{{ $message }}
<a href = "{{$return_url}}"> {!!trans('messages.label_back_to_page')!!}</a>