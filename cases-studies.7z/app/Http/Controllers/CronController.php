<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Election;
use App\ElectionType;
use App\ElectionStatus;


class CronController extends Controller
{
     
     public $user_group_id_register;
     public $user_group_id_guest;
     public $status_id_active; 
     public $periphery_id_prefix;
     public $polling_station_status_unregistered;
     public $polling_station_status_registered;
     public $polling_station_status_problematic;
     public $polling_station_status_sent;
     public $polling_station_status_edited_for_resend;
     public $polling_station_status_sent_but_problematic;

    public function __construct()
    {
     
        $this->user_group_id_register = config('app.USER_GROUP_ID_REGISTER');
        $this->user_group_id_guest = config('app.USER_GROUP_ID_GUEST');
        $this->status_id_active = config('app.ELECTION_STATUS_ACTIVE'); 
        $this->periphery_id_prefix= config('app.PERIPHERY_ID_PREFIX');
        $this->polling_station_status_unregistered= config('app.POLLING_STATION_STATUS_UNREGISTERED');
        $this->polling_station_status_registered= config('app.$this->POLLING_STATION_STATUS_REGISTERED');
        $this->polling_station_status_problematic= config('app.POLLING_STATION_STATUS_PROBLEMATIC');
        $this->polling_station_status_sent= config('app.POLLING_STATION_STATUS_SENT');
        $this->polling_station_status_edited_for_resend= config('app.$this->POLLING_STATION_STATUS_EDITED_FOR_RESEND');
        $this->polling_station_status_sent_but_problematic= config('app.POLLING_STATION_STATUS_SENT_BUT_PROBLEMATIC');
        $this->middleware(function ($request, $next) {
            $serverIP = getHostByName(getHostName());

            /*
            var_dump($serverIP);
            var_dump($request->server('SERVER_ADDR'));
            var_dump($request->ip());
            die();
            */

            if (!in_array($request->ip() , [ '127.0.0.1', '::1'])) {
                abort(403);
            }
            return $next($request);
        });
   
    }


    public function send() {

        $header = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:wser="http://wservices/"><soapenv:Header/><soapenv:Body><wser:wsreply><!--Optional:-->';
        $footer = '<!--Optional:--><username>ABC</username><!--Optional:--><password>**##**</password></wser:wsreply></soapenv:Body></soapenv:Envelope>';
        // For every election
        $data['elections']= Election::select('election_id, election_type_id')
                                ->where('status_id','=',$this->status_id_active )
                                ->whereRaw('exists (select 1 from votes where status_id in ( ? , ? ) and locked_by is null)',
                                    [$this->polling_station_status_registered,$this->polling_station_status_edited_for_resend])->orderBy('election_type_id')->get();
        foreach( $data['elections'] as $election) {
            

            $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><parameter></parameter>');

            $xml->addChild('electionType', $election->election_type_id);
            $electoralPeripheries = $xml->addChild('electoralPeripheries');

            //foreach($db->query('SELECT ep.eklogikes_perifereies_name, et.peripheryID 
            //FROM eklogikes_perifereies ep 
            //INNER JOIN eklogika_tmimata et WHERE et.ws_state < 2 
            //AND ep.eklogikes_perifereies_id = et.peripheryID GROUP BY et.peripheryID') as $row) { 
            $mydata = new \stdClass();
            $mydata->rows = array();
            // For every eklogiki periferia
            $data['electoral_regions']=DB::select('select electoral_regions.electoral_region_id , electoral_regions.electoral_region_name
            FROM elections
            CROSS JOIN  electoral_regions
            INNER JOIN polling_stations  on polling_stations.electoral_region_id = electoral_regions.electoral_region_id
            INNER JOIN votes  on elections.election_id= votes.election_id and polling_stations.municipality_id = votes.municipality_id and polling_stations.polling_station_id = votes.polling_station_id
            WHERE elections.election_id = '. $election->election_id . '
            and votes.status_id in ('. $this->polling_station_status_registered. ','. $this->polling_station_status_edited_for_resend.') and votes.locked_by is null
            GROUP BY electoral_regions.electoral_region_id , electoral_regions.electoral_region_name');

            foreach($data['electoral_regions'] as $electoral_region) {
                
            // For every eklogiki periferia
                $electoralPeripheries->addChild('peripheryID', $this->periphery_id_prefix . $electoral_region->electoral_region_id);
                $electoralPeripheries->addChild('name', $electoral_region->electoral_region_name);
                
            // For every eklogiko tmima
            $data['polling_stations']=DB::Select('select municipalities.municipality_id, municipalities.municipality_name, votes.polling_station_id, 
                votes.registered, votes.voted, votes.votes_valid, votes.votes_invalid, votes.votes_blanc, votes.status_id, polling_stations.is_heterodimotes
                FROM votes 
                INNER JOIN polling_stations  on votes.polling_station_id = polling_stations.polling_station_id and votes.municipality_id = polling_stations.municipality_id
                INNER JOIN municipalities  on polling_stations.municipality_id = municipalities.municipality_id
                WHERE votes.election_id = '.$election->election_id.'
                and polling_stations.electoral_region_id = '.$electoral_region->electoral_region_id. '
                and votes.status_id in ('. $this->polling_station_status_registered. ',' . $this->polling_station_status_edited_for_resend.') 
                and votes.locked_by is null');
                foreach($data['polling_stations'] as $polling_station) {

                    $departments = $electoralPeripheries->addChild('departments');
                    $departments->addChild('otaId', $polling_station->municipality_id);
                    $departments->addChild('otaName', $$polling_station->municipality_name);
                    $departments->addChild('id', $polling_station->polling_station_id);
                    $departments->addChild('registered', $polling_station->registered);
                    $departments->addChild('voted', $polling_station->voted);
                    $departments->addChild('valid', $polling_station->votes_valid);
                    $departments->addChild('invalid', $polling_station->votes_invalid);
                    $departments->addChild('blanc', $polling_station->votes_blanc);
                    $departments->addChild('update', $polling_station->status_id);
                    $departments->addChild('eterodim', $polling_station->is_heterodimotes);

                    // cache values for this pollling_station in order to execute update command in votes table
                    $temp = new \stdClass();
                    $temp->election_id = $election->election_id;
                    $temp->municipality_id = $polling_station->municipality_id;
                    $temp->polling_station_id = $$polling_station->polling_station_id;
                    $mydata->rows[]=$temp;

                    // For every party
                    //foreach($db->query('SELECT v.komma_id, v.komma_votes, k.komma_name FROM votes v INNER JOIN kommata k WHERE v.eklogika_tmhmata_id = '.$row2['eklogika_tmhmata_id'].' AND v.peripheryID = '.$row['peripheryID'].' AND v.komma_id = k.komma_id_areios_pagos') as $row3	) { // For every party
                    $data['parties_votes']=DB::select('SELECT parties.party_id, parties.party_name, parties_votes.votes 
                    FROM parties_votes 
                    INNER JOIN parties on parties_votes.election_id = parties.election_id and parties_votes.party_id =parties.party_id 
                    WHERE parties_votes.election_id='. $election->election_id .' 
                    AND parties_votes.municipality_id = '. $polling_station->municipality_id .' 
                    AND parties_votes.polling_station_id= '.$polling_station->polling_station_id);
                    foreach($data['parties_votes'] as $partyvote) { // For every party
                        $votes = $departments->addChild('votes');
                        $votes->addChild('partyId', $partyvote->party_id);
                        $votes->addChild('partyName', $partyvote->party_name);
                        $votes->addChild('votesCount', $partyvote->votes);
                    }
                }
            }

            $main = $xml->asXML();

            $removeXML = str_replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>','',$main);
            $DataToSend = $header . $removeXML . $footer;

            $httpRequest = curl_init();
            $url = 'http://10.2.66.67:8080/test1/ElectionsService';
            curl_setopt($httpRequest, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($httpRequest, CURLOPT_HTTPHEADER, array("Content-Type:  text/xml"));
            curl_setopt($httpRequest, CURLOPT_POST, 1);
            curl_setopt($httpRequest, CURLOPT_HEADER, 1);

            curl_setopt($httpRequest, CURLOPT_URL, $url);
            curl_setopt($httpRequest, CURLOPT_POSTFIELDS, $DataToSend);

            $returnHeader = curl_exec($httpRequest);
            if (strpos($returnHeader, '<responseText>everything ok</responseText>') !== false) {
                echo config('app.ELECTION_SEND_ID_SUCCEED')."\n";
                // $stmt_wsUpdateStatement = $db->prepare($wsUpdateStatement);
                // $stmt_wsUpdateStatement->execute();
                $currentDate=DB::selectraw('select now()')->get();
                foreach ($mydata->rows as $row) {
                    //echo 'municip. '.$row->municipality_id.' polling:' .$row->polling_station_id.'<br/>';
                    $affected = DB::update('update votes set send_date= ? , status_id=?,
                    where election_id=? and municipality_id=? and polling_station_id=?', [$currentDate, $this->polling_startion_status_sent,$row->election_id,$row->municipality_id,$row->polling_station_id]);
                    $k = $k+$affected;
                }
                echo $k. " Εκλογικά Τμήματα εστάλθησαν!!";
            }
            else {
                echo  config('app.ELECTION_SEND_ID_FAILED')."\n";
            }
            curl_close($httpRequest);	
        }
    }
}
?>