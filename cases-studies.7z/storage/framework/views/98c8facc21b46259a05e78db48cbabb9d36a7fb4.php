<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo trans('messages.title_stations_send'); ?></h2>
                <form id="part-form" action="<?php echo e(url('/send')); ?>" method="get">
                    <input type="hidden" name="id" value="0"/>
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <div class="col-sm-12">
                                <?php if($data['send_msg_id'] == config('app.CASE_STATION_SEND_ID_SUCCEED') ): ?>
                                <label><?php echo trans('messages.case_station_send_success'); ?></label>
                                <label><?php echo trans('messages.case_sent_to_main_server'); ?><?php echo e(': '); ?> <?php echo e($data['updated']); ?><?php echo trans('messages.case_sent_to_main_server'); ?></label>
                                <?php elseif($data['send_msg_id'] == config('app.CASE_STATION_SEND_ID_FAILED') ): ?>
                                <label><?php echo trans('messages.case_station_send_failed'); ?></label>
                                <?php elseif($data['send_msg_id'] == config('app.CASE_STATION_SEND_ID_UNDER_CONSTRUCTION') ): ?>
                                <label><?php echo trans('messages.case_send_under_construction'); ?></label>
                                <?php else: ?>
                                <label><?php echo trans('Unknown Message!!'); ?></label>
                                <?php endif; ?>
                        </div>
                    </div>

                    <div class="clr"></div>
                    <div class="sep-20"></div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <a href="<?php echo e(url('/')); ?>" class="btn btn-danger"><?php echo trans('messages.return'); ?></a>
                        </div>
                    </div>
            </div>
            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footerScript'); ?>
    <script type="text/javascript">
        $(function () {
        
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>