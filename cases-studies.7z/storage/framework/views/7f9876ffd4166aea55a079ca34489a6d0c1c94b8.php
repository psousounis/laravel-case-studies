<?php $__env->startSection('content'); ?>
  
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">

                <?php if($data['user_cases_count'] > 1 ): ?>
                <div>
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-default btn-lg">
                       <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> <?php echo trans('messages.return_cases'); ?></a>
                <div>
                <?php endif; ?>
                    <?php if($data['case']): ?>
                    <h3 class="cases-main-header">
                    <div
                            class="list-title pull-left alert alert-info col-sm-12" ><?php echo e($data['case']->case_descr); ?><?php echo e(' / '); ?> <?php echo e(trans('messages.stations_list')); ?>

                    </div>
                    </h3>
                    <?php endif; ?>

                <div class="col-sm-12">
                    <!-- <label><?php echo trans('messages.user_quick_information'); ?></label> -->
                    <h4>
                    <label><?php echo trans('messages.total_stations'); ?></label>
                    <?php $__currentLoopData = $data['user_total_stations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="total-rows"><?php echo e($row->total_rows); ?></label>
                        <span class='start parenthesis'>(</span>

                            <?php $__currentLoopData = $data['user_stations_analysis']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <!-- <?php echo e($row->total_stations); ?>-->
                                <?php if($key !=0): ?> <?php echo e('/'); ?> <?php endif; ?>
                                <label class='user case-region'><?php echo e($value->case_region_name); ?><?php echo e(': '); ?><?php echo e($value->total_stations); ?> (<?php echo e($value->station_id_from); ?>-<?php echo e($value->station_id_to); ?>)</label>
                                <!--foreach ( $data['user_stations_analysis'] as $row) -->
                         <!--   <label class='user case-region'><?php echo e($row->case_region_name); ?>(<?php echo e($row->station_id_from); ?>-<?php echo e($row->station_id_to); ?>)</label>  -->
                          <!--  }   -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <span class='end parenthesis'>)</span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </h4>
                </div>

                <!--<div class="clr"></div>         -->
                
                    
                        
                            <div id="toolbar-search" class="pull-right">
                                <div class="form" role="form">
                                <div class='cases-buttons-block'>
                                        <?php $__currentLoopData = $data['stations_not_registered']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($station->status_id== config('app.STATION_STATUS_UNREGISTERED') ): ?>
                                            <div class="col-sm-2 card p-3 mb-2 text-white btn bg-primary hovered"
                                                 id="label_not_registered">
                                                <div class="card-body">
                                                    <span class="card-title"><?php echo trans('messages.stations_not_registered'); ?> (<?php echo e($station->total_rows); ?>)</span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $data['stations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( ($station->status_id== config('app.STATION_STATUS_PROBLEMATIC')) ): ?>
                                                    <div class="col-sm-2 card text-white btn bg-danger hovered"
                                                         id="label_problematic">
                                                        <div class="card-body ">
                                                            <span class="card-title"><?php echo trans('messages.stations_problematic'); ?> (<?php echo e($station->total_rows); ?>)</span>
                                                        </div>
                                                    </div>
                                        <?php elseif($station->status_id== config('app.STATION_STATUS_REGISTERED') ): ?>
                                                    <div class="col-sm-2 card text-white btn bg-warning hovered"
                                                         id="label_registered">
                                                        <div class="">
                                                            <div class="card-body">
                                                                <span class="card-title"><?php echo trans('messages.stations_register'); ?> (<?php echo e($station->total_rows); ?>)</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                        <?php elseif($station->status_id== config('app.STATION_STATUS_SENT') ): ?>
                                                    <div class="col-sm-2 card text-white btn bg-success hovered"
                                                         id="label_sent">
                                                        <div class="">
                                                            <div class="card-body">
                                                                <span class="card-title"><?php echo trans('messages.stations_sent'); ?> (<?php echo e($station->total_rows); ?>)</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                        <?php elseif($station->status_id== config('app.STATION_STATUS_EDITED_FOR_RESEND') ): ?>
                                                    <div class="col-sm-2 card text-info btn bg-info hovered"
                                                         id="label_resend">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <span class="card-title"><?php echo trans('messages.stations_resent'); ?> (<?php echo e($station->total_rows); ?>)</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                        <?php elseif($station->status_id== config('app.STATION_STATUS_SENT_BUT_PROBLEMATIC')): ?>
                                                    <div class="col-sm-2 card text-danger btn bg-danger hovered"
                                                         id="label_sent_but_problematic">
                                                        <div class="">
                                                            <div class="card-body">
                                                                <span class="card-title"><?php echo trans('messages.stations_sent_but_problematic'); ?> (<?php echo e($station->total_rows); ?>)</span>
                                                                <!-- <a  name="label_sent_but_problematic" id="label_sent_but_problematic" href="javascript:void(0);">Προβολή</a> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class='search-box'>
                                        <div class="col-sm-4">
                                        <!--  <label><?php echo trans('messages.select_case_regions'); ?></label> -->
                                            <select class="form-control drop-select" name="search_case_region"
                                                    id="search_case_region">
                                                <option value="">-- <?php echo trans('messages.select_case_region'); ?> -- </option>
                                                <?php $__currentLoopData = $data['case_regions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case_region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($case_region->case_region_id); ?>"><?php echo e($case_region->case_region_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-4">
                                        <!-- <label><?php echo trans('messages.select_municipality'); ?></label> -->
                                            <select class="form-control drop-select2" name="search_municipality"
                                                    id="search_municipality">
                                                <option value="">-- <?php echo trans('messages.select_municipality'); ?>--</option>
                                                <?php $__currentLoopData = $data['municipalities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($municipality->municipality_id); ?>"><?php echo e($municipality->municipality_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-4">
                                            <!-- <label><?php echo trans('messages.select_status'); ?></label>  -->
                                            <select class="form-control drop-select" name="search_status" id="search_status">
                                                <option value="">-- <?php echo trans('messages.select_status'); ?> --</option>
                                                <?php $__currentLoopData = $data['stations_statuses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($status->status_id); ?>"><?php echo e($status->status_descr); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-4">
                                        <!--  <label><?php echo trans('messages.select_station'); ?></label>     -->
                                        <input type="number" name="search_station"  class="form-control"
                                            maxlength="5" size="5"  placeholder="<?php echo trans('messages.placeholder_station'); ?>">
                                        </div>
                                    </div>

                                    <div class="col-sm-4 search-buttons-box">
                                        <button id="btn-search" type="submit"
                                                class="btn btn-success"><?php echo trans('messages.search'); ?></button>
                                        <button id="btn-clear-search" type="submit"
                                                class="btn btn-danger"><?php echo trans('messages.clear'); ?></button>
                                    </div>

                                </div>
                                </div>
                            </div>

                        
                    
                


                <table id="table"
                       class="table table-condensed table-striped stations-table"
                       data-toolbar="#toolbar"
                       data-show-refresh="false"
                       data-show-toggle="false"
                       data-show-columns="false"
                       data-show-export="true"
                       data-detail-formatter="detailFormatter"
                       data-minimum-count-columns="1"
                       data-pagination="true"
                       data-id-field="id"
                       data-page-list="[25, 50, 100, ALL]"
                       data-show-footer="false"
                       data-side-pagination="server"
                       data-url="<?php echo e(url('/')); ?>/<?php echo e($data['case_id']); ?>/stations/data"
                       data-query-params="queryParams"
                       data-search-on-enter-key="true"
                       data-striped ="true"
                       data-cookie="true"
                       data-cookie-id-table="station-id"
                       data-response-handler="responseHandler">
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerScript'); ?>
    <script>

        var $table = $('#table');
        var $remove = $('#remove');
        var selections = [];
        var options= "";



        function initTable() {
            $table.bootstrapTable({
                height: getHeight(),
                pageSize: 25,
                columns: [
                    {
                        field: 'status_id',
                        title: '<?php echo trans('messages.operation'); ?>',
                        sortable: true,
                        events: operateEvents,
                        formatter: statusFormatter,
                        align: 'center'
                    },
                    {
                        field: 'action_id',
                        title: '<?php echo trans('messages.action'); ?>',
                        visible: false
                    },
                    {
                        field: 'case_region_id',
                        title: '<?php echo trans('messages.case_region_id'); ?>',
                        visible: false
                    },
                    {
                        field: 'case_region_name',
                        title: '<?php echo trans('messages.title_case_region'); ?>',
                        sortable: true,
                        align: 'center'
                    },
                    {
                        field: 'municipality_name',
                        title: '<?php echo trans('messages.title_municipality'); ?>',
                        sortable: true,
                        align: 'center',
                    },
                    {
                        field: 'id',
                        title: '<?php echo trans('messages.title_station'); ?>',
                        align: 'center',
                        valign: 'middle',
                        sortable: true
                    },
                    {
                        field: 'status_descr',
                        title: '<?php echo trans('messages.title_status_descr'); ?>',
                        sortable: true,
                        align: 'center'
                    },
                     <?php if(Auth::user()->group_id == config('app.USER_GROUP_ID_ADMIN') or Auth::user()->group_id == config('app.USER_GROUP_ID_SUPERVISOR') ): ?>
                    {
                        field: 'user_name',
                        title: '<?php echo trans('messages.title_user'); ?>',
                        align: 'center'
                    },
                     <?php endif; ?>

                ]
            });
            setTimeout(function () {
                $table.bootstrapTable('resetView');
            }, 200);

            $table.on('check.bs.table uncheck.bs.table ' +
                    'check-all.bs.table uncheck-all.bs.table', function () {
                $remove.prop('disabled', !$table.bootstrapTable('getSelections').length);
                selections = getIdScases();
            });
            $table.on('all.bs.table', function (e, name, args) {
                if (name == 'load-success.bs.table') {
                }
            });
            $remove.click(function () {
                var ids = getIdScases();
                $table.bootstrapTable('remove', {
                    field: 'id',
                    values: ids
                });
                $remove.prop('disabled', true);
            });
            $(window).resize(function () {
                $table.bootstrapTable('resetView', {
                    height: getHeight()
                });
            });
            $('[data-toggle="tooltip"]').tooltip();
        }
        function getIdSelections() {
            return $.map($table.bootstrapTable('getSelections'), function (row) {
                return row.id
            });
        }
        function responseHandler(res) {
            $.each(res.rows, function (i, row) {
                row.state = $.inArray(row.id, selections) !== -1;
            });
            return res;
        }


        function statusFormatter(value, row, index) {
          // console.log(row.status_id);
          // console.log(row.case_region_id);
            if  ( (value== <?php echo e($data['station_status_registered']); ?> ) || (value== <?php echo e($data['station_status_edited_for_resend']); ?> ) ) {
                <?php if(Auth::user()->group_id == 1 ): ?>
                    return [
                            '<a class="edit" href="javascript:void(0)" title="<?php echo trans('messages.edit'); ?>">',
                            '<i class="glyphicon glyphicon-edit"></i>',
                            '</a> ',
                            '<span class="operate-seperator">|</span>',
                            '<a class="send" href="javascript:void(0)" title="<?php echo trans('messages.send'); ?>">',
                            '<i class="glyphicon glyphicon-send"></i>',
                            '</a> ',
                            ].join('');
                <?php else: ?>
                    return [
                            '<a class="edit" href="javascript:void(0)" title="<?php echo trans('messages.edit'); ?>">',
                            '<i class="glyphicon glyphicon-edit"></i>',
                            '</a> ',
                            ].join('');
                <?php endif; ?>

            } else if ( (value == <?php echo e($data['station_status_problematic']); ?>) || (value==<?php echo e($data['station_status_sent_but_problematic']); ?>)) {
                return [
                    '<a class="edit" href="javascript:void(0)" title="<?php echo trans('messages.edit'); ?>">',
                    '<i class="glyphicon glyphicon-edit"></i>',
                    '</a> ',
                ].join('');
            } else if ( value == <?php echo config('app.STATION_STATUS_UNREGISTERED'); ?> ) {
                return [
                    '<a class="edit" href="javascript:void(0)" title="<?php echo trans('messages.add'); ?>">',
                    '<i class="glyphicon glyphicon-plus"></i>',
                    '</a> ',
                ].join('');
            } else {
                return [ ].join('');
            };

        }

        function statusFormatterGood(value, row, index) {
            if ( value>0 ) {
                if   ( (value == <?php echo e($data['station_status_problematic']); ?>) || (value == 4) )  {
                    return [
                            '<a class="edit" href="javascript:void(0)" title="<?php echo trans('messages.edit'); ?>">',
                            '<i class="glyphicon glyphicon-edit"></i>',
                            '</a> ',
                            '<span class="operate-seperator">|</span>',
                            '<a class="edit" href="javascript:void(0)" title="<?php echo trans('messages.send'); ?>">',
                            '<i class="glyphicon glyphicon-send"></i>',
                            '</a> ',
                            ].join('');
                } else {
                    return [
                            '<a class="edit" href="javascript:void(0)" title="<?php echo trans('messages.edit'); ?>">',
                            '<i class="glyphicon glyphicon-edit"></i>',
                            '</a> ',
                            ].join('');
                }
            } else if ( value ==<?php echo e($data['station_status_unregistered']); ?> ) {
                return [
                '<a class="edit" href="javascript:void(0)" title="<?php echo trans('messages.add'); ?>">',
                '<i class="glyphicon glyphicon-plus"></i>',
                '</a> ',
                ].join('');
            } else {
                return [ ].join('');
            };

        }

        function detailFormatter(index, row) {
            return;
            var html = [];
            $.each(row, function (key, value) {
                html.push('<p><b>' + key + ':</b> ' + value + '</p>');
            });
            return html.join('');
        }

        window.operateEvents = {
            'click .create': function (e, value, row, index) {
                window.location.href = "<?php echo e(url('/')); ?>/<?php echo e($data['case_id']); ?>/stations/"+ row.case_region_id +'/' + row.id + '/detail?action_id=1';
            },
            'click .edit': function (e, value, row, index) {
                window.location.href = "<?php echo e(url('/')); ?>/<?php echo e($data['case_id']); ?>/stations/"+ row.case_region_id +'/' + row.id + '/detail?action_id='+ row.action_id;
            },
            'click .send': function (e, value, row, index) {
                window.location.href = "<?php echo e(url('/')); ?>/<?php echo e($data['case_id']); ?>/stations/"+ row.case_region_id +'/' + row.id +  + row.id + '/send';
            },
            'click .remove': function (e, value, row, index) {
                var r = confirm("<?php echo trans('messages.confirm_delete_station'); ?>");
                if (r == true) {
                    $.ajax({
                        url: '<?php echo e(url('/')); ?>/stations/destroy',
                        type: 'POST',
                        data: {id: row.id},
                        success: function (result) {
                            $table.bootstrapTable('remove', {
                                field: 'id',
                                values: [row.id]
                            });
                        },
                        error: function (result) {

                        }
                    });
                }
            },

        };

        $('#btn-search').click(function () {
            $table.bootstrapTable('refresh');
        });

        function queryParams(params) {

            if ($('select[name=search_case_region]').val() >0) {
                params['search_case_region'] = $('select[name=search_case_region]').val();
            }
            if ($('input[name=search_station]').val() >0) {
                params['search_station'] = $('input[name=search_station]').val();
            }
            if ($('select[name=search_municipality]').val() >0) {
                params['search_municipality'] = $('select[name=search_municipality]').val();
            }
            //parseInt
            if ( parseInt($('select[name=search_status]').val())>0 || parseInt($('select[name=search_status]').val()) ==-1) {
                 params['search_status'] = $('select[name=search_status]').val();
            }

            return params;
        }


        function savePreferences() {

            var settingsEvents = {};

            settingsEvents.search_case_region = $('select[name=search_case_region]').val();
            settingsEvents.search_municipality = $('select[name=search_municipality]').val();
            settingsEvents.search_status = $('select[name=search_status]').val();
            if ($('input[name=search_station]').val()>0) {
                settingsEvents.search_station = $('input[name=search_station]').val();
            }
            localStorage.setItem('settingsEvents', JSON.stringify(settingsEvents));
        }

        function getPreferences() {

            var settingsEvents = JSON.parse(localStorage.getItem('settingsEvents'));
            if (settingsEvents) {
                if (settingsEvents.search_case_region)
                    $('select[name=search_case_region]').val(settingsEvents.search_case_region);
                if (settingsEvents.search_municipality)
                    $('select[name=search_municipality]').val(settingsEvents.search_municipality);
                if (settingsEvents.search_status)
                    $('select[name=search_status]').val(settingsEvents.search_status);
                if (settingsEvents.search_station>0) {
                    $('input[name=search_station]').val(settingsEvents.search_station);
                }

            }
        }
        $('#search_municipality, #search_case_region, #search_status').change(function(){
            refreshBootstrapTable();
        });

        $('#btn-clear-search').click(function () {
            $('select[name=search_case_region]').val('');
            $('input[name=search_station]').val('');
            $('select[name=search_municipality]').val('');
            $('select[name=search_status]').val('');
            //$table.bootstrapTable('refresh');
            refreshBootstrapTable();
        });

        function getHeight() {
            return $(window).height() - $('h1').outerHeight(true);
        }
        function ClearForm() {
            $('select[name=search_case_region]').val('');
            $('select[name=search_municipality]').val('').trigger('change');
            $('select[name=search_status]').val('');
            $('input[name=search_station]').val('');
            return true;
        }

        function refreshBootstrapTable() {
            document.cookie = 'station-id.bs.table.pageNumber=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            savePreferences();
            $table.bootstrapTable('selectPage', 1);
            $table.bootstrapTable('refresh');
        }

        $('#label_not_registered').click (function() {
            ClearForm();
            $('select[name=search_status]').val(<?php echo e(config('app.STATION_STATUS_UNREGISTERED')); ?>);
            refreshBootstrapTable();

            //If you don't want the link to actually
            // redirect the browser to another page,
            // "google.com" in our example here, then
            // return false at the end of this block.
            // Note that this also prevents event bubbling,
            // which is probably what we want here, but won't
            // always be the case.
            return false;
        });

        $('#label_registered').click ( function() {
            ClearForm();
            $('select[name=search_status]').val(<?php echo e(config('app.STATION_STATUS_REGISTERED')); ?>);
            refreshBootstrapTable();

            //If you don't want the link to actually
            // redirect the browser to another page,
            // "google.com" in our example here, then
            // return false at the end of this block.
            // Note that this also prevents event bubbling,
            // which is probably what we want here, but won't
            // always be the case.
            return false;
        });

        $('#label_problematic').click( function() {
            ClearForm();
            $('select[name=search_status]').val(<?php echo e(config('app.STATION_STATUS_PROBLEMATIC')); ?>);
            refreshBootstrapTable();

            //If you don't want the link to actually
            // redirect the browser to another page,
            // "google.com" in our example here, then
            // return false at the end of this block.
            // Note that this also prevents event bubbling,
            // which is probably what we want here, but won't
            // always be the case.
            return false;
        });

        $('#label_sent_problematic').click( function() {
            ClearForm();
            $('select[name=search_status]').val(<?php echo e(config('app.STATION_STATUS_SENT_BUT_PROBLEMATIC')); ?>);
            refreshBootstrapTable();

            //If you don't want the link to actually
            // redirect the browser to another page,
            // "google.com" in our example here, then
            // return false at the end of this block.
            // Note that this also prevents event bubbling,
            // which is probably what we want here, but won't
            // always be the case.
            return false;
        });

        $('#label_sent').click (function() {
            ClearForm();
            $('select[name=search_status]').val(<?php echo e(config('app.STATION_STATUS_SENT')); ?>);
            refreshBootstrapTable();

            //If you don't want the link to actually
            // redirect the browser to another page,
            // "google.com" in our example here, then
            // return false at the end of this block.
            // Note that this also prevents event bubbling,
            // which is probably what we want here, but won't
            // always be the case.
            return false;
        });

        $('#label_resend').click (function() {
            ClearForm();
            $('select[name=search_status]').val(<?php echo e(config('app.STATION_STATUS_EDITED_FOR_RESEND')); ?>);
            refreshBootstrapTable();

            //If you don't want the link to actually
            // redirect the browser to another page,
            // "google.com" in our example here, then
            // return false at the end of this block.
            // Note that this also prevents event bubbling,
            // which is probably what we want here, but won't
            // always be the case.
            return false;
        });

        $(function () {
            // pansou vars
            var labelNotRegistered = document.getElementById("label_not_registered");
            var labelRegistered = document.getElementById("label_register");
            var labelProblematic = document.getElementById("label_problematic");
            var labelSent = document.getElementById("label_sent");
            var labelResend = document.getElementById("label_resend");

            getPreferences();
            initTable();
            $('.drop-select2').select2();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>